from caldis.core.component import Component


class Mixer(Component):
    """Adiabatic mixing junction: two inlet streams merge into one outlet.
    Sign convention: inlet mdot > 0, outlet mdot < 0.
    All three ports share the same pressure (constant-pressure mixing).
    """

    def __init__(self, name, backend):
        super().__init__(name)
        self.backend = backend
        self.in1 = self.add_port("in1", backend=backend)
        self.in2 = self.add_port("in2", backend=backend)
        self.out = self.add_port("out", backend=backend)

    def residuals(self):
        return [
            self.in1.mdot + self.in2.mdot + self.out.mdot,            # mass
            self.in1.mdot * self.in1.h
            + self.in2.mdot * self.in2.h
            + self.out.mdot * self.out.h,                             # energy (signed mdot)
            self.in2.p - self.in1.p,                                 # equal pressure
            self.out.p - self.in1.p,                                 # equal pressure
        ]

    def residual_names(self):
        return ["mass", "energy", "p_in2", "p_out"]

    def update_outputs(self):
        self._outputs = {"mdot_out": -self.out.mdot}   # > 0: total mixed flow

    @property
    def mdot_out(self): return self._outputs["mdot_out"]

    def _own_start_sanity(self):
        return [
            (self.in1.mdot > 0, f"{self.path}: in1 mdot should be > 0 (inlet)"),
            (self.in2.mdot > 0, f"{self.path}: in2 mdot should be > 0 (inlet)"),
            (self.out.mdot < 0, f"{self.path}: out mdot should be < 0 (outlet)"),
        ]