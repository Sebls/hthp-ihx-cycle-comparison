from caldis.core.component import Component


class Splitter(Component):
    """Flow splitter: one inlet divides into two outlets at the same state.
    Sign convention: inlet mdot > 0, outlet mdot < 0.
    Both outlets share the inlet pressure and enthalpy; the mass split is set
    by the downstream network, not by this component.
    """

    def __init__(self, name, backend):
        super().__init__(name)
        self.backend = backend
        self.inl  = self.add_port("inl",  backend=backend)
        self.out1 = self.add_port("out1", backend=backend)
        self.out2 = self.add_port("out2", backend=backend)

    def residuals(self):
        return [
            self.inl.mdot + self.out1.mdot + self.out2.mdot,   # mass
            self.out1.h - self.inl.h,                          # equal enthalpy
            self.out2.h - self.inl.h,
            self.out1.p - self.inl.p,                          # equal pressure
            self.out2.p - self.inl.p,
        ]

    def residual_names(self):
        return ["mass", "h_out1", "h_out2", "p_out1", "p_out2"]

    def update_outputs(self):
        self._outputs = {"mdot_in": self.inl.mdot}

    @property
    def mdot_in(self): return self._outputs["mdot_in"]

    def _own_start_sanity(self):
        return [
            (self.inl.mdot > 0,  f"{self.path}: inl mdot should be > 0 (inlet)"),
            (self.out1.mdot < 0, f"{self.path}: out1 mdot should be < 0 (outlet)"),
            (self.out2.mdot < 0, f"{self.path}: out2 mdot should be < 0 (outlet)"),
        ]