from caldis.core.component import Component


class FlashTank(Component):
    """Adiabatic flash separator at constant pressure.
    A two-phase stream enters and is split into saturated vapour and
    saturated liquid at the tank pressure.
    Sign convention: inlet mdot > 0, outlet mdot < 0.
    Ports: inl (two-phase in), vap (saturated vapour out), liq (saturated liquid out).
    """

    def __init__(self, name, backend):
        super().__init__(name)
        self.backend = backend
        self.inl = self.add_port("inl", backend=backend)
        self.vap = self.add_port("vap", backend=backend)
        self.liq = self.add_port("liq", backend=backend)

    def residuals(self):
        be = self.backend
        p  = self.inl.p
        hg = be.h_pq(p, 1.0)      # saturated-vapour enthalpy (from pressure)
        hf = be.h_pq(p, 0.0)      # saturated-liquid enthalpy  (from pressure)
        return [
            self.inl.mdot + self.vap.mdot + self.liq.mdot,                 # mass
            self.inl.mdot * self.inl.h
            + self.vap.mdot * hg
            + self.liq.mdot * hf,                                          # energy (sat enthalpies)
            self.vap.h - hg,                                               # saturated vapour (x=1)
            self.liq.h - hf,                                               # saturated liquid (x=0)
            self.vap.p - self.inl.p,                                       # equal pressure
            self.liq.p - self.inl.p,                                       # equal pressure
        ]

    def residual_names(self):
        return ["mass", "energy", "sat_vapour", "sat_liquid", "p_vap", "p_liq"]

    def update_outputs(self):
        m_in = self.inl.mdot
        self._outputs = {
            "mdot_in": m_in,
            "vapour_fraction": (-self.vap.mdot) / m_in if m_in else 0.0,
        }

    @property
    def vapour_fraction(self): return self._outputs["vapour_fraction"]

    def _own_start_sanity(self):
        return [
            (self.inl.mdot > 0, f"{self.path}: inl mdot should be > 0 (inlet)"),
            (self.vap.mdot < 0, f"{self.path}: vap mdot should be < 0 (outlet)"),
            (self.liq.mdot < 0, f"{self.path}: liq mdot should be < 0 (outlet)"),
        ]