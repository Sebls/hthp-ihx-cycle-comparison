from caldis.core.component import Component
from caldis.components.vessels.control_volume import ControlVolume
from caldis.components.vessels.thermal_mass import ThermalMass


class TankConstV(Component):
    """Composite: fluid volume (ControlVolume) + wall (ThermalMass), coupled by
    Q = UA_wall*(T_wall - T_fluid). A heater Q_heater is applied to the wall.
    The tank's fluid ports ARE the inner volume's ports (aliases). The coupling is
    injected into the children via their Qdot (computed in _own_residuals, re-
    evaluated each iteration -> captured by the Jacobian)."""

    def __init__(self, name, backend, V, p_init, h_init,
                 C_wall, T_wall_init, UA_wall, Q_heater=0.0):
        super().__init__(name)
        self.backend = backend
        self.params.update(UA_wall=UA_wall, Q_heater=Q_heater)
        self.fluid = self.add_child(
            ControlVolume("fluid", backend=backend, V=V,
                          p_init=p_init, h_init=h_init, Qdot=0.0))
        self.wall = self.add_child(
            ThermalMass("wall", C=C_wall, UA=0.0,
                        T_init=T_wall_init, T_env=T_wall_init, Qdot_ext=0.0))
        self.inl = self.fluid.inl        # alias: tank exposes the volume's ports
        self.out = self.fluid.out

    def _own_residuals(self):
        UA = self.params["UA_wall"]
        Qh = self.params["Q_heater"]
        T_f = self.backend.T(self.fluid.p, self.fluid.h)
        T_w = self.wall.T
        Q = UA * (T_w - T_f)                          # wall -> fluid
        self._Q_coupling = Q                          # kept for update_outputs
        self.fluid.params["Qdot"] = Q                 # fluid receives +Q
        self.wall.params["Qdot_ext"] = Qh - Q         # wall: heater - Q released
        return []

    def update_outputs(self):
        self._outputs = {
            "Q": getattr(self, "_Q_coupling", 0.0),
            "T_fluid": self.backend.T(self.fluid.p, self.fluid.h),
            "T_wall": self.wall.T,
        }

    @property
    def Q(self): return self._outputs["Q"]
    @property
    def T_fluid(self): return self._outputs["T_fluid"]
    @property
    def T_wall(self): return self._outputs["T_wall"]


class ControlVolumeP(Component):
    """0-D two-phase control volume at CONSTANT PRESSURE (variable volume).

    Counterpart of ControlVolume: there V is fixed and p is algebraic; here p is a
    fixed PARAMETER and V becomes an algebraic unknown (the volume breathes to keep the
    pressure constant).

    Energy balance with a MOVING boundary
    -------------------------------------
    The boundary does work on the surroundings at the rate p*dV/dt, so the internal
    energy balance of a breathing control volume is

        dU/dt = H_flow + Qdot - p*dV/dt      (p*dV/dt = boundary work done BY the CV)

    Tracking U directly would require dV/dt. Instead we track the TOTAL ENTHALPY
    H = M*h as the differential state: since H = U + p*V at constant p,

        dH/dt = dU/dt + p*dV/dt = H_flow + Qdot

    so the boundary work cancels and the enthalpy balance carries NO work term. This is
    the clean constant-pressure form (and avoids a dV/dt unknown). U is recovered as
    U = H - p*V when needed.

    States: M (mass), H (total enthalpy). Algebraic: V, h. Qdot prescribed (param,
    possibly driven by a composite parent)."""

    def __init__(self, name, backend, p, h_init, V_init, Qdot=0.0):
        super().__init__(name)
        self.backend = backend
        self.params.update(p=p, Qdot=Qdot)
        rho0 = backend.rho(p, h_init)
        M0 = V_init * rho0
        H0 = M0 * h_init                               # total enthalpy (state)
        self._M = self.add_variable("M", start=M0, differential=True)
        self._H = self.add_variable("H", start=H0, differential=True)
        self._V = self.add_variable("V", start=V_init, lower=0.0)
        self._h = self.add_variable("h", start=h_init)
        self.inl = self.add_port("inl", backend=backend)
        self.out = self.add_port("out", backend=backend)
        for port in (self.inl, self.out):
            port._p.start = p
            port._h.start = h_init

    # public value access
    @property
    def M(self): return self._M.value
    @property
    def H(self): return self._H.value
    @property
    def U(self):                                       # derived: U = H - p*V
        return self._H.value - self.params["p"] * self._V.value
    @property
    def V(self): return self._V.value
    @property
    def h(self): return self._h.value
    @property
    def p(self): return self.params["p"]               # imposed, constant

    def residuals(self):
        p = self.params["p"]
        Qdot = self.params["Qdot"]
        h, V = self._h.value, self._V.value
        rho = self.backend.rho(p, h)
        Hflow = self.inl.mdot * self.inl.h + self.out.mdot * self.out.h
        return [
            self._M.der - (self.inl.mdot + self.out.mdot),   # mass
            self._H.der - (Hflow + Qdot),                    # enthalpy (pdV absorbed)
            self._M.value - V * rho,                         # mass / volume relation
            self._H.value - self._M.value * h,               # H = M*h
            self.inl.p - p,
            self.out.p - p,
            self.out.h - h,
        ]

    def residual_names(self):
        return ["mass_dyn", "energy_dyn", "M_def", "H_def",
                "inl_p", "out_p", "out_h"]

    def update_outputs(self):
        p, h = self.params["p"], self._h.value
        self._outputs = {
            "rho": self.backend.rho(p, h),
            "T": self.backend.T(p, h),
            "x": self.backend.quality(p, h),
            "V": self._V.value,
            "U": self.U,
        }

    @property
    def rho(self): return self._outputs["rho"]
    @property
    def T(self): return self._outputs["T"]
    @property
    def x(self): return self._outputs["x"]
    @property
    def V_out(self): return self._outputs["V"]

    # --- exergy ---------------------------------------------------------------
    def stored_exergy(self, T0, p0):
        """Closed-system (non-flow) exergy of the contents relative to (T0, p0):
        Phi = M*[(u - u0) - T0*(s - s0) + p0*(v - v0)], always >= 0. Same expression
        as the rigid tank; here v = V/M uses the CURRENT (variable) volume."""
        be = self.backend
        M = self._M.value
        p = self.params["p"]
        h = self._h.value
        v = self._V.value / M
        u = h - p * v                                  # u = h - p*v
        s = be.s(p, h)
        h0 = be.h_pt(p0, T0)
        v0 = 1.0 / be.rho(p0, h0)
        u0 = h0 - p0 * v0
        s0 = be.s(p0, h0)
        return M * ((u - u0) - T0 * (s - s0) + p0 * (v - v0))

    def exergy_balance(self, T0, p0):
        """Storage component: report the stored (closed-system) exergy, not a steady
        supplied/recovered pair. Xdot_destroyed is left to the integrated balance of a
        phase (dynamic storage), as for ControlVolume."""
        Qdot = self.params.get("Qdot", 0.0)
        Tf = self.backend.T(self.params["p"], self._h.value)
        Xheat = Qdot * (1.0 - T0 / Tf) if abs(Qdot) > 1e-12 else 0.0
        d = self._exergy_dict(T0, p0, Xdot_heat=Xheat,
                              X_stored=self.stored_exergy(T0, p0))
        d["Xdot_destroyed"] = None
        self.Xdot_destroyed = None
        return d


class TankConstP(Component):
    """Composite constant-pressure (variable-volume) storage: fluid volume
    (ControlVolumeP) + wall (ThermalMass), coupled by Q = UA_wall*(T_wall - T_fluid).
    A heater Q_heater is applied to the wall. The tank's fluid ports ARE the inner
    volume's ports (aliases). Same structure as the constant-volume Tank; only the inner
    volume differs (pressure imposed, volume free, moving-boundary work accounted for via
    the enthalpy state).

    Exergy: the composite itself has no steady-state product, so exergy_balance returns
    None (same as TankConstV). The stored (closed-system) exergy lives on the inner
    volume: access it via self.fluid.stored_exergy(T0, p0) or self.fluid.X_stored after
    compute_exergy()."""

    def __init__(self, name, backend, p, h_init, V_init,
                 C_wall, T_wall_init, UA_wall, Q_heater=0.0):
        super().__init__(name)
        self.backend = backend
        self.params.update(UA_wall=UA_wall, Q_heater=Q_heater)
        self.fluid = self.add_child(
            ControlVolumeP("fluid", backend=backend, p=p,
                           h_init=h_init, V_init=V_init, Qdot=0.0))
        self.wall = self.add_child(
            ThermalMass("wall", C=C_wall, UA=0.0,
                        T_init=T_wall_init, T_env=T_wall_init, Qdot_ext=0.0))
        self.inl = self.fluid.inl        # alias: tank exposes the volume's ports
        self.out = self.fluid.out

    def _own_residuals(self):
        UA = self.params["UA_wall"]
        Qh = self.params["Q_heater"]
        T_f = self.backend.T(self.fluid.p, self.fluid.h)
        T_w = self.wall.T
        Q = UA * (T_w - T_f)                          # wall -> fluid
        self._Q_coupling = Q                          # kept for update_outputs
        self.fluid.params["Qdot"] = Q                 # fluid receives +Q
        self.wall.params["Qdot_ext"] = Qh - Q         # wall: heater - Q released
        return []

    def update_outputs(self):
        self._outputs = {
            "Q": getattr(self, "_Q_coupling", 0.0),
            "T_fluid": self.backend.T(self.fluid.p, self.fluid.h),
            "T_wall": self.wall.T,
            "V": self.fluid.V,
        }

    @property
    def Q(self): return self._outputs["Q"]
    @property
    def T_fluid(self): return self._outputs["T_fluid"]
    @property
    def T_wall(self): return self._outputs["T_wall"]
    @property
    def V(self): return self._outputs["V"]

    def exergy_balance(self, T0, p0):
        return None    # composite storage: stored exergy lives on self.fluid
