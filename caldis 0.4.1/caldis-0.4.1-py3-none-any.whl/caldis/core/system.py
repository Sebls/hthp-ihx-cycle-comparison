import numpy as np

class System:
    def __init__(self, name="system"):
        self.name = name
        self.components = []
        self.connections = []
        self.constraints = []          # callables () -> résidu (float), contraintes système
        self.unknowns = []
        self._assembled = False
        self._start_hints = []
        self._port_hints = []

    def add(self, *components):
        self.components.extend(components)
        self._assembled = False
        return components[0] if len(components) == 1 else components

    def connect(self, port_a, port_b, close_loop=False):
        from caldis.core.connection import Connection
        conn = Connection(port_a, port_b, close_loop=close_loop)
        self.connections.append(conn)
        self._assembled = False
        return conn

    def add_constraint(self, fn, name=""):
        if name and any(n == name for n, _ in self.constraints):
            raise ValueError(f"contrainte {name!r} déjà présente "
                             f"(utiliser replace_constraint pour l'écraser)")
        self.constraints.append((name, fn))
        self._assembled = False
        return fn

    def remove_constraint(self, name):
        n0 = len(self.constraints)
        self.constraints = [(n, f) for (n, f) in self.constraints if n != name]
        if len(self.constraints) == n0:
            raise KeyError(f"aucune contrainte nommée {name!r} à retirer "
                           f"(présentes : {[n for n, _ in self.constraints]})")
        self._assembled = False

    def replace_constraint(self, name, fn):
        """Retire puis rajoute : pratique pour changer une valeur cible."""
        self.remove_constraint(name)
        self.add_constraint(fn, name)

    def constraint_names(self):
        return [n for n, _ in self.constraints]

    def assemble(self):
        self.unknowns = [v for c in self.components for v in c.all_variables()]
        for i, v in enumerate(self.unknowns):
            v.index = i
        self._assembled = True
        return self

    def x0(self):
        return np.array([v.start for v in self.unknowns], dtype=float)

    def set_x(self, x):
        for v, xi in zip(self.unknowns, x):
            v.value = float(xi)

    def residuals(self):
        r = []
        for c in self.components:
            r += list(c.residuals())
        for conn in self.connections:
            r += list(conn.residuals())
        for _, fn in self.constraints:
            r.append(fn())
        return np.array(r, dtype=float)

    def n_unknowns(self):
        return len(self.unknowns)

    def n_equations(self):
        return len(self.residuals())

    def check(self):
        if not self._assembled:
            self.assemble()
        for c in self.components:
            c.check()

    def collect_outputs(self):
        into = {}
        for c in self.components:
            c.collect_outputs(into)
        return into

    def scales(self):
        import numpy as np
        out = []
        for v in self.unknowns:
            if v.scale and v.scale > 0:
                out.append(v.scale)                     # scale explicite respecté
            else:
                out.append(max(abs(v.start), 1.0))      # auto : magnitude physique du start
        return np.array(out, dtype=float)
    
    def bounds(self):
        import numpy as np
        lo = np.array([v.lower if v.lower is not None else -np.inf for v in self.unknowns])
        hi = np.array([v.upper if v.upper is not None else  np.inf for v in self.unknowns])
        return lo, hi

    def set_start(self, component, p=None, T=None, mdot=None, side=None):
        """Level-2 deferred start hint (applied by init_starts, AFTER level-1).
        side: 'r' (r_* ports), 's' (s_* ports), None (all fluid ports of the component).
        p sets the pressure; T recomputes h via h_pt(p, T); mdot (magnitude) is signed
        per inlet(+)/outlet(-). Any argument left None keeps the level-1 value."""
        self._start_hints.append((component, p, T, mdot, side))
        return self

    def _apply_start_hint(self, comp, p, T, mdot, side):
        for port in comp.ports:
            name = port.name
            if side is not None and not name.startswith(side + "_"):
                continue
            be = port.backend
            if p is not None:
                port._p.start = p
            if T is not None and be is not None:
                port._h.start = be.h_pt(port._p.start, T)
            if mdot is not None:
                port._mdot.start = (-mdot if name.endswith("out") else mdot)

    def set_start_port(self, port, p=None, T=None, h=None, mdot=None):

        """Level-2 hint at PORT granularity (deferred, applied by init_starts after
        level-1). Needed for heat exchangers whose inlet/outlet are at different
        states. p sets pressure; T recomputes h via h_pt(p,T); h sets it directly;
        mdot is the signed start. None keeps the level-1 value."""
        self._port_hints.append((port, p, T, h, mdot))
        return self

    def check_start_sanity(self, verbose=True):
        """Level-2 diagnostic: check each component's physical preconditions at the
        current start point. Warns (does not raise) so you can still try to solve.
        Returns the list of failed checks."""
        if not self._assembled:
            self.assemble()
        self.set_x(self.x0())
        failed = []
        for c in self.components:
            for ok, msg in c.start_sanity():
                if not ok:
                    failed.append(msg)
        if verbose:
            if failed:
                print("Start sanity WARNINGS (start point may not converge):")
                for m in failed:
                    print("  ⚠ " + m)
            else:
                print("Start sanity: all component preconditions satisfied.")
        return failed

    def residual_labels(self):
        """Human label for each residual, in the SAME order as residuals().
        Lets diagnostics point at which equation is violated."""
        
        labels = []
        for c in self.components:
            n = len(c.residuals())
            names = getattr(c, "residual_names", lambda: None)()
            if names is not None and len(names) == n:
                labels += [f"{c.path}.{nm}" for nm in names]
            else:
                labels += [f"{c.path}[{i}]" for i in range(n)]

        for conn in self.connections:
            kinds = ["p", "h"] if conn.close_loop else ["p", "h", "mdot"]
            a = f"{conn.a.owner.name}.{conn.a.name}"
            b = f"{conn.b.owner.name}.{conn.b.name}"
            labels += [f"conn {a}.{k} = {b}.{k}" for k in kinds]

        for name, _ in self.constraints:
            labels.append(f"constraint:{name}")
        return labels

    def _all_ports(self):
        def walk(c):
            ports = [(c, p) for p in c.ports]
            for child in c.children:
                ports += walk(child)
            return ports
        out = []
        for c in self.components:
            out += walk(c)
        return out

    def port_table(self, as_dataframe=True):
        """Tabulate every fluid port after a solve. Two temperature columns to avoid
        unit confusion: T [K], T_C [°C]. Other columns in engineering units."""
        rows = []
        for comp, port in self._all_ports():
            be = port.backend
            T = s = x = rho = None
            if be is not None:
                try:
                    T = port.T
                    s = be.s(port._p.value, port._h.value)
                    x = be.quality(port._p.value, port._h.value)
                    rho = be.rho(port._p.value, port._h.value)
                except Exception:
                    pass
            rows.append({
                "component": comp.path, "port": port.name,
                "p_bar": port.p / 1e5,
                "T": T,
                "T_C": (None if T is None else T - 273.15),
                "h_kJkg": port.h / 1e3,
                "s_kJkgK": (None if s is None else s / 1e3),
                "x": x, "rho": rho, "mdot": port.mdot,
            })
        if as_dataframe:
            try:
                import pandas as pd
                return pd.DataFrame(rows).set_index(["component", "port"])
            except ImportError:
                pass
        return rows
    
    def init_starts(self, T_default=283.15, verbose=False):
        """Two-level fluid-aware start initialization.
        Level 1: fluid-aware default (p, h) on every port.
        Level 2a: per-side hints (set_start).  2b: per-port hints (set_start_port).
        Call after building the system, before solving."""
        if not self._assembled:
            self.assemble()

        # --- level 1: fluid-aware defaults on all ports (recurses into children) ---
        for c in self.components:
            c.apply_default_starts(T_default)

        # --- level 2a: per-side hints ---
        for (comp, p, T, mdot, side) in self._start_hints:
            self._apply_start_hint(comp, p, T, mdot, side)

        # --- level 2b: per-port hints (finest) ---
        for (port, p, T, h, mdot) in self._port_hints:
            be = port.backend
            if p is not None:
                port._p.start = p
            if h is not None:
                port._h.start = h
            elif T is not None:
                if be is None:
                    raise ValueError(f"set_start_port({port.path}, T=...) needs a "
                                     f"backend on the port, but none is attached")
                port._h.start = be.h_pt(port._p.start, T)
            if mdot is not None:
                port._mdot.start = mdot

        # --- level 3: internal starts (port->cell propagation + explicit overrides) ---
        for c in self.components:
            c.seed_internal_starts()
        
        # --- load starts into current values ---
        self.set_x(self.x0())
        if verbose:
            print(f"init_starts: level-1 + {len(self._start_hints)} side + "
                  f"{len(self._port_hints)} port hints")
        return self

    def structure(self, depth=None):

        """Print the structure of every top-level component in the system."""
        for c in self.components:
            c.structure(depth=depth)
            print()
        return None

    def set_reference(self, T_ref, p_ref=101325.0):
        """Dead state for exergy analysis (call before exergy_report)."""
        self.T_ref = T_ref
        self.p_ref = p_ref

    def exergy_report(self, T_ref=None, p_ref=None, as_dataframe=True):

        T0 = T_ref if T_ref is not None else getattr(self, "T_ref", None)
        p0 = p_ref if p_ref is not None else getattr(self, "p_ref", 101325.0)
        if T0 is None:
            raise ValueError("no reference temperature: call set_reference(T_ref) first")
        rows = []
        for c in self.components:
            bal = c.exergy_balance(T0, p0)     # computes AND writes onto c
            if bal is None:
                continue
            rows.append({"component": c.path, **bal})
        if as_dataframe:
            try:
                import pandas as pd
                return pd.DataFrame(rows).set_index("component")
            except ImportError:
                pass
        return rows

    def set_start_internal(self, component, base_name, value):
        """Set internal-variable starts of a component, by base name (one call for
        all elements): scalar = uniform, list = per-element profile. Symmetric with
        set_start_port. Call before init_starts."""
        component.set_internal_start(base_name, value)
        return self


    def physical_check(self, verbose=True):
        """Post-solve physical validity (e.g. no temperature cross).
        Warns but never raises; returns the list of failed-check messages."""
        failed = []
        for c in self.components:
            failed += [msg for ok, msg in c.physical_check() if not ok]
        if verbose and failed:
            print("PHYSICAL-VALIDITY WARNINGS (converged, but the solution may be non-physical):")
            for m in failed:
                print("  /!\\ " + m)
        return failed

    def fix_port(self, port, p=None, T=None, h=None, mdot=None):
        """Impose port quantities AND record BOUNDARY start anchors (see
        caldis.solvers.autostart.fix_port). Thin method wrapper."""
        from caldis.solvers.autostart import fix_port as _fix_port
        return _fix_port(self, port, p=p, T=T, h=h, mdot=mdot)

    def autostart(self, T_default=283.15, verbose=False):
        """Automatic start propagation (see caldis.solvers.autostart.autostart).
        Thin method wrapper; replaces init_starts()."""
        from caldis.solvers.autostart import autostart as _autostart
        return _autostart(self, T_default=T_default, verbose=verbose)

    def compute_exergy(self, res, T0=None, p0=None):
        """Post-process a dynamic run: recompute every component's exergy balance for the
        dead state (T0,p0) and splice the results into `res` as time series. No re-solve
        (each step's state is replayed via set_x). Best-effort: a term that raises -> NaN.
        Re-callable with a different dead state without re-running simulate."""
        import numpy as np
        T0 = T0 if T0 is not None else getattr(self, "T_ref", None)
        p0 = p0 if p0 is not None else getattr(self, "p_ref", None)
        if T0 is None or p0 is None:
            raise ValueError("no dead state: pass T0,p0 or call set_reference() first")
        X = getattr(res, "x_history", None)
        if X is None:
            raise ValueError("res has no x_history (re-run simulate with patch B)")
        series = {}
        for k in range(len(res.time)):
            self.set_x(X[k])
            for c in self.components:
                try:
                    bal = c.exergy_balance(T0, p0)
                except Exception:
                    bal = None
                if not bal:
                    continue
                for key, val in bal.items():
                    series.setdefault(f"{c.path}.{key}", []).append(
                        np.nan if val is None else float(val))
        for key, vals in series.items():
            arr = np.asarray(vals, dtype=float)
            res._hist[key] = arr
            res._root._add(key.split("."), arr)
        self.T_ref, self.p_ref = T0, p0
        return res

    def exergy_report(self, res=None, at=-1, as_dataframe=True, digits=3):
        """Display-only exergy table. With `res`, reads the series written by
        compute_exergy at time index `at` (default: last step). Without `res`, falls back
        to the current (solved) state. Does not itself run the heavy solve."""
        import numpy as np
        keys = ["Xdot_flow_in","Xdot_flow_out","Xdot_work","Xdot_heat","X_stored",
                "Xdot_destroyed","Xdot_supplied","Xdot_recovered","eta_II", 'balance']
        rows = []
        for c in self.components:
            full0 = f"{c.path}.X_stored"
            if res is not None and any(f"{c.path}.{k}" in res._hist for k in keys):
                row = {"component": c.path}
                for k in keys:
                    fk = f"{c.path}.{k}"
                    row[k] = res._hist[fk][at] if fk in res._hist else np.nan
                rows.append(row)
            elif res is None:
                try:
                    bal = c.exergy_balance(self.T_ref, self.p_ref)
                except Exception:
                    bal = None
                if bal:
                    rows.append({"component": c.path, **bal})
        if as_dataframe:
            import pandas as pd
            df = pd.DataFrame(rows).set_index("component")
            return df.round(digits)        # <-- arrondi d'affichage
        return rows